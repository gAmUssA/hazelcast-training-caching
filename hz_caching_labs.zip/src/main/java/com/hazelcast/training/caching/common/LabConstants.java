package com.hazelcast.training.caching.common;

/**
 * TODO
 *
 * @author Viktor Gamov on 8/26/15.
 *         Twitter: @gamussa
 * @since 0.0.1
 */
public class LabConstants {
    public static final String IMAP_NAME = "company";
}
