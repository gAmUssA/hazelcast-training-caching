java -cp hsqldb.jar org.hsqldb.Server
